package com.cg.mywallet.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.mywallet.bean.WalletAccount;
import com.cg.mywallet.bean.WalletTransaction;
import com.cg.mywallet.exception.WalletException;
import com.cg.mywallet.service.WalletService;
import com.cg.mywallet.service.WalletServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WalletService service=new WalletServiceImpl();
		Scanner sc=new Scanner(System.in);
		int loopController = 0;
		String username,password;
		double amount;
		WalletAccount w=new WalletAccount();
		do
		{
			System.out.println("1-Create Account");
			System.out.println("2-Show Balance");
			System.out.println("3-Deposit");
			System.out.println("4-Withdraw");
			System.out.println("5-Fund Transfer");
			System.out.println("6-Print Transaction");
			System.out.println("7-Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
				case 1: System.out.println("Enter your User Name and password");
				try {
					System.out.println("Account with Username= "+service.createAccount(new WalletAccount(sc.next(),0,sc.next())).getUserName()
							+" created.");
				} catch (WalletException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
						break;
				case 2: System.out.println("Enter Username and password");
						username=sc.next();
						password=sc.next();
						try{
							System.out.println(service.showBalance(username, password));
						}catch(Exception e){
							System.out.println(e.getMessage());
							//e.printStackTrace();
						}
						break;
				case 3: System.out.println("Enter Username and amount");
						username=sc.next();
						amount=sc.nextDouble();
						try
						{
							w=service.deposit(username, amount);
							System.out.println("Rs. "+amount+" deposited successfully");
							System.out.println("Updated account details");
							System.out.println(w);
						}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
						break;
				case 4: System.out.println("Enter Username,password and amount");
						username=sc.next();
						password=sc.next();
						amount=sc.nextDouble();
						try
						{
							w=service.withdraw(username, password, amount);
							System.out.println("Rs. "+amount+" withdrawn successfully");
							System.out.println("Updated account details");
							System.out.println(w);
						}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
						break;
				case 5: System.out.println("Enter Username,password and amount");
						username=sc.next();
						password=sc.next();
						amount=sc.nextDouble();
						System.out.println("Enter receiver's username");
						String toUserName=sc.next();
						try{
							for(WalletAccount wallet:service.fundTransfer(username, password, toUserName, amount))
								System.out.println("Updated bank account: "+wallet);
						}catch(Exception e) {
							System.out.println(e.getMessage());
						}
						break;
				case 6: System.out.println("Enter Username and password");
						username=sc.next();
						password=sc.next();
						try{
							List<WalletTransaction> lw=new ArrayList<WalletTransaction>(service.printTransactions(username, password));
							System.out.println(lw);
							//System.out.println(service.printTransactions(username, password));
						}catch (Exception e) {
							// TODO: handle exception
							System.out.println(e.getMessage());
						}
						break;
				case 7: System.exit(0);
			}
			System.out.println("Enter 1 to continue or any other number to exit");
			loopController=sc.nextInt();
		}while(loopController==1);
	}
	}


