package com.cg.mywallet.db;
import java.time.LocalDateTime;
import java.util.*;

import com.cg.mywallet.bean.WalletAccount;
import com.cg.mywallet.bean.WalletTransaction;
public class Staticdb {
	private static HashMap<String, WalletAccount> wMap=new HashMap<String, WalletAccount>();
	private static HashMap<String, List<WalletTransaction>> tMap=new HashMap<String,List<WalletTransaction>>();
	
	static
	{
		wMap.put("User1",new WalletAccount("Soumya1",0,"Ssm@123"));
		wMap.put("User2",new WalletAccount("Swarup2",0,"Swa@456"));
		tMap.put("User1",new ArrayList<WalletTransaction>());
		tMap.put("User2",new ArrayList<WalletTransaction>());
		tMap.get("User1").add(new WalletTransaction("User1", "Deposit",1000.0 , 1000,LocalDateTime.now()));
		wMap.get("User1").setBalance(1000);
		tMap.get("User1").add(new WalletTransaction("User1", "Withdraw",500 , 500,LocalDateTime.now() ));
		wMap.get("User1").setBalance(500);
		tMap.get("User1").add(new WalletTransaction("User1", "Transfer(debit)",250 , 250,LocalDateTime.now() ));
		tMap.get("User2").add(new WalletTransaction("User2", "Transfer(credit)",250 , 250,LocalDateTime.now() ));
		wMap.get("User1").setBalance(250);
		wMap.get("User2").setBalance(250);
	}
	public static HashMap<String, WalletAccount> getWMap()
	{
		return wMap;
	}
	
	public static HashMap<String,List<WalletTransaction>> getTMap()
	{  //System.out.println(tMap);
		return tMap;
	}

}
