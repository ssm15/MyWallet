package com.cg.mywallet.dao;

import com.cg.mywallet.bean.WalletAccount;
import com.cg.mywallet.bean.WalletTransaction;
import com.cg.mywallet.exception.WalletException;

import java.util.*;

public interface WalletDao {
	public WalletAccount createAccount(WalletAccount acc)throws WalletException ;
	public double showBalance(String username,String password)throws WalletException ;
	public WalletAccount deposit(String username,double amount)throws WalletException ;
	public WalletAccount withdraw(String username,String password,double amount)throws WalletException ;
	public List<WalletAccount> fundTransfer(String fromUserName,String fromPassword,String toUserName,double amount)throws WalletException;
	public List<WalletTransaction> printTransactions(String username,String password)throws WalletException ;

}
